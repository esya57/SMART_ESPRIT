#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"

int y = 1;
int x = 2;
personne n;

//////////////////////////////////////////////////////////////////////////////////
void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)

{
GtkWidget *windowmenu, *windowlogin;
GtkWidget *entry1,*entry2, *label39;
char log[20];
char pw[20];
int trouve;

windowlogin=lookup_widget(button,"windowlogin");
entry1 = lookup_widget (button,"entry1");
entry2 = lookup_widget (button,"entry2");
label39 = lookup_widget(button,"label39");
strcpy(n.nomutilisateur,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(n.motdepasse,gtk_entry_get_text(GTK_ENTRY(entry2)));
strcpy(log,n.nomutilisateur);
strcpy(pw,n.motdepasse);
trouve=verif(log,pw); 

if (trouve==1)
{

windowmenu= create_windowmenu ();
gtk_widget_hide(windowlogin);
gtk_widget_show(windowmenu);
}
else
gtk_widget_show(label39);
}

////////////////////////////////////////////////////////////////////////////////////
void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{ 
int pass = 1;
GtkWidget *entry3 ,*entry4 ,*entry5, *entry7, *label38;
char text1[20];
personne n;
FILE *f=NULL;
GtkWidget *windowlogin,*output ;
GtkWidget *combobox1,*windowinscri,*ejour,*emois,*eannee;

windowinscri = lookup_widget (button,"windowinscri");
entry3 = lookup_widget (button,"entry3");
entry4 = lookup_widget(button,"entry4");
entry5 = lookup_widget(button,"entry5");
entry7 = lookup_widget(button,"entry6");
label38 = lookup_widget(button,"label38");

ejour=lookup_widget (button,"jour");
emois=lookup_widget (button,"mois");
eannee=lookup_widget (button,"annee");

strcpy(n.prenom ,gtk_entry_get_text(GTK_ENTRY(entry3)));
strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(entry4)));
strcpy(n.nomutilisateur,gtk_entry_get_text(GTK_ENTRY(entry5)));
strcpy(n.motdepasse,gtk_entry_get_text(GTK_ENTRY(entry7)));

n.datnaissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ejour));
n.datnaissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(emois));
n.datnaissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(eannee));

combobox1 = lookup_widget(button, "combobox1") ;

if (x==1)
strcpy (n.sexe,"Femme");
else if  (x==2)
strcpy (n.sexe,"Homme");

if(strcmp(n.nom,"")==0 || strcmp(n.prenom,"")==0 || strcmp(n.nomutilisateur,"")==0 || strcmp(n.motdepasse,"")==0 || strcmp(gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)),"")==0 ){
pass =0;
gtk_widget_show(label38);
} else 
{
if(strcmp("Agent du Foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
strcpy(n.role,"Agent_du_Foyer");

else if(strcmp("Agent du Restaurant ",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
strcpy(n.role,"Agent_du_Restaurant");

else
strcpy(n.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
}

if(pass == 1 ) {
f=fopen("utilisateur.txt","a+");
if (f!= NULL)
{

fprintf(f,"%s %s %s %s %s %s %d %d %d \n",n.prenom,n.nom,n.nomutilisateur,n.motdepasse,n.sexe,n.role,n.datnaissance.jour,n.datnaissance.mois,n.datnaissance.annee);
fclose(f);
 
}
gtk_widget_hide(windowinscri);
windowlogin= create_windowlogin ();
gtk_widget_show(windowlogin); 
}

}



////////////////////////////////////////////////////////////////////////////////////
void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowlogin, *windowinscri;
windowlogin= create_windowlogin ();
windowinscri = lookup_widget(button,"windowinscri");
gtk_widget_hide(windowinscri);
gtk_widget_show(windowlogin);

}

////////////////////////////////////////////////////////////////////////////////////*
void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}

////////////////////////////////////////////////////////////////////////////////////
void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowadmin, *windowmenu;

windowmenu = lookup_widget(button,"windowmenu");
windowadmin= create_windowadmin ();
gtk_widget_hide(windowmenu);
gtk_widget_show(windowadmin);
}

////////////////////////////////////////////////////////////////////////////////////*
void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}

////////////////////////////////////////////////////////////////////////////////////*
void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}

////////////////////////////////////////////////////////////////////////////////////*
void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{


}

////////////////////////////////////////////////////////////////////////////////////*
void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}

////////////////////////////////////////////////////////////////////////////////////
void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowlogin2, *windowmenu;

windowmenu=lookup_widget(button,"windowmenu");
windowlogin2= create_windowlogin ();
gtk_widget_hide(windowmenu);
gtk_widget_show(windowlogin2);

}

////////////////////////////////////////////////////////////////////////////////////
void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *windowmenu, *windowadmin;

windowadmin=lookup_widget(button,"windowadmin");
windowmenu= create_windowmenu ();
gtk_widget_hide(windowadmin);
gtk_widget_show(windowmenu);

}

////////////////////////////////////////////////////////////////////////////////////


void
on_button12_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview1,*windowadmin;
windowadmin=lookup_widget(objet,"windowadmin");
treeview1=lookup_widget(windowadmin,"treeview1");
afficher_personne(treeview1);
}

////////////////////////////////////////////////////////////////////////////////////
void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry8;
char nomutilisateur[20];

    FILE*f;
    FILE*h;
     
    entry8 = lookup_widget (button,"entry8");
    strcpy(nomutilisateur,gtk_entry_get_text(GTK_ENTRY(entry8)));
   

    f=fopen("utilisateur.txt","r");
    h=fopen("test2.txt","a+");

   if(f==NULL && h==NULL)
	printf("desole");
    
    
   	 while(fscanf(f,"%s %s %s %s %s %s %d %d %d \n ",n.prenom,n.nom,n.nomutilisateur,n.motdepasse,n.sexe,n.role,&n.datnaissance.jour,&n.datnaissance.mois,&n.datnaissance.annee)!=EOF ) 
    {
        if (strcmp(nomutilisateur,n.nomutilisateur)!=0)
            {
                fprintf(h,"%s %s %s %s %s %s %d %d %d \n",n.prenom,n.nom,n.nomutilisateur,n.motdepasse,n.sexe,n.role,n.datnaissance.jour,n.datnaissance.mois,n.datnaissance.annee);



            }
    }
    fclose(f);
    fclose(h);
    remove("utilisateur.txt");
    rename("test2.txt","utilisateur.txt");

}

////////////////////////////////////////////////////////////////////////////////////
void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowinscri, *windowlogin;
windowlogin = lookup_widget(button,"windowlogin");
windowinscri=create_windowinscri();
gtk_widget_hide(windowlogin);
gtk_widget_show(windowinscri);
}

////////////////////////////////////////////////////////////////////////////////////
void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=1;}
}

////////////////////////////////////////////////////////////////////////////////////
void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=2;}
}

////////////////////////////////////////////////////////////////////////////////////
void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=2;}
}

////////////////////////////////////////////////////////////////////////////////////
void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=1;}
}

////////////////////////////////////////////////////////////////////////////////////
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* prenom;
gchar* nom;
gchar* nomutilisateur;
gchar* motdepasse;
gchar* sexe;
gchar* role;
gint* jour;
gint* mois;
gint* annee;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&prenom,1,&nom,2,&nomutilisateur,3,&motdepasse,4,&sexe,5,&role,6,&jour,7,&mois,8,&annee, -1);

strcpy(n.prenom,prenom);
strcpy(n.nom,nom);
strcpy(n.nomutilisateur,nomutilisateur);
strcpy(n.motdepasse,motdepasse);
strcpy(n.sexe,sexe);
strcpy(n.role,role);
n.datnaissance.jour=jour;
n.datnaissance.mois=mois;
n.datnaissance.annee=annee;
afficher_personne(treeview);
}
afficher_personne(treeview);
}
///////////////////////////////////////////////////////////////////////////////////
void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
char text2[20]="Femme";
personne n;
FILE *f=NULL;
int pass = 1;
GtkWidget *windowmenu,*windowadmin,*entry9,*entry10,*entry12,*entry11,*entry13, *label40;
GtkWidget *fjour,*fmois,*fannee;


windowadmin = lookup_widget(button,"windowadmin");
entry9 = lookup_widget (windowadmin,"entry9");
entry10 = lookup_widget(windowadmin,"entry10");
entry12 = lookup_widget(windowadmin,"entry12");
entry11 = lookup_widget(windowadmin,"entry11");
label40 = lookup_widget(windowadmin,"label40");


fjour=lookup_widget (windowadmin,"jourx");
fmois=lookup_widget (windowadmin,"moisx");
fannee=lookup_widget (windowadmin,"anneex");

strcpy(n.prenom,gtk_entry_get_text(GTK_ENTRY(entry9)));
strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(entry10)));
strcpy(n.nomutilisateur,gtk_entry_get_text(GTK_ENTRY(entry12)));
strcpy(n.motdepasse,gtk_entry_get_text(GTK_ENTRY(entry11)));


n.datnaissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(fjour));
n.datnaissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(fmois));
n.datnaissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(fannee));

GtkWidget *combobox2;
combobox2 = lookup_widget(windowadmin, "combobox2") ;

if(y==1)
	strcpy(text2,"Femme");
else if (y==2)
	strcpy(text2,"Homme");


if(strcmp(n.nom,"")==0 || strcmp(n.prenom,"")==0 || strcmp(n.nomutilisateur,"")==0 || strcmp(n.motdepasse,"")==0 || strcmp(gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)),"")==0 ){
pass=0;
gtk_widget_show(label40);
}
else {
if(strcmp("Agent du Foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)))==0)
strcpy(n.role,"Agent_du_Foyer");

else if(strcmp("Agent du Restaurant ",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)))==0)
strcpy(n.role,"Agent_du_Restaurant");

else
strcpy(n.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
}
if(pass ==1)
{
f=fopen("utilisateur.txt","a+");
if (f!= NULL)
{

fprintf(f,"%s %s %s %s %s %s %d %d %d \n",n.prenom,n.nom,n.nomutilisateur,n.motdepasse,text2,n.role,n.datnaissance.jour,n.datnaissance.mois,n.datnaissance.annee);
fclose(f);
 
}
windowmenu= create_windowmenu ();
gtk_widget_hide(windowadmin);
gtk_widget_show(windowmenu); 
}

}




void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry13;
GtkWidget *windowmenu, *windowadmin;
char nomutilisateur[20];

    FILE*f;
    FILE*g;
    
    windowadmin = lookup_widget(button,"windowadmin");
    entry13 = lookup_widget (button,"entry13");
    strcpy(nomutilisateur,gtk_entry_get_text(GTK_ENTRY(entry13)));
   

    f=fopen("utilisateur.txt","r");
    g=fopen("test3.txt","a+");

   if(f==NULL && g==NULL)
	printf("desole");
    
    
   	 while(fscanf(f,"%s %s %s %s %s %s %d %d %d \n ",n.prenom,n.nom,n.nomutilisateur,n.motdepasse,n.sexe,n.role,&n.datnaissance.jour,&n.datnaissance.mois,&n.datnaissance.annee)!=EOF ) 
    {
        if (strcmp(nomutilisateur,n.nomutilisateur)!=0)
            {
                fprintf(g,"%s %s %s %s %s %s %d %d %d \n",n.prenom,n.nom,n.nomutilisateur,n.motdepasse,n.sexe,n.role,n.datnaissance.jour,n.datnaissance.mois,n.datnaissance.annee);

 

            }
    }
    fclose(f);
    fclose(g);
    remove("utilisateur.txt");
    rename("test3.txt","utilisateur.txt");

windowmenu= create_windowmenu ();
gtk_widget_hide(windowadmin);
gtk_widget_show(windowmenu); 

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_button19_e_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *entry14_e;
GtkWidget  *treeview1;
char nomutilisateur_rech[20];



treeview1=lookup_widget(objet,"treeview1");
entry14_e=lookup_widget(objet,"entry14_e");
strcpy(nomutilisateur_rech,gtk_entry_get_text(GTK_ENTRY(entry14_e)));
rech_personne (nomutilisateur_rech,treeview1);

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



