#include "callbacks.h"
#include "fonction.h"
#include <stdio.h>
#include <string.h>
enum
{
Prenom,
Nom,
Nomutilisateur,
Motdepasse,
Sexe,
Role,
Jour,
Mois,
Annee,
COLUMNS
};

int verif(char log[],char pw[])
{
int trouve=-1;
FILE *f=NULL;
//char ch1[20];
//char ch2[20];
personne n;
f=fopen("utilisateur.txt","r");
if (f!=NULL)
{
/*while (fscanf(f,"%s %s \n",ch1,ch2)!=EOF)*/ while(fscanf(f,"%s %s %s %s %s %s %d %d %d \n ",n.prenom,n.nom,n.nomutilisateur,n.motdepasse,n.sexe,n.role,&n.datnaissance.jour,&n.datnaissance.mois,&n.datnaissance.annee)!=EOF ) 
{
if ((strcmp(n.nomutilisateur,log)==0)&&(strcmp(n.motdepasse,pw)==0))
trouve=1;
}
fclose(f);
}
return (trouve);
}
//////////////////////////////////////////////////////////////////////////////////
void afficher_personne(GtkWidget *liste)
{

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store; 
  
char prenom[20];
char nom[20];
char nomutilisateur[20];
char motdepasse[20];
char sexe[20];
char role[20];
int jour,mois,annee;	
store = NULL;
personne n;
  FILE *f;
	
  store=gtk_tree_view_get_model(liste);

  if (store==NULL)
  {

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",Prenom,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",Nom,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nomutilisateur",renderer,"text",Nomutilisateur,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("motdepasse",renderer,"text",Motdepasse,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",Sexe,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("role",renderer,"text",Role,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",Jour,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("mois",renderer,"text",Mois,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("annee",renderer,"text",Annee,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

 store=gtk_list_store_new(COLUMNS,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);

    f = fopen("utilisateur.txt","r");

    if (f==NULL)
    {
      return;
    }
    else
    
     { f = fopen("utilisateur.txt","a+");
      while(fscanf(f,"%s %s %s %s %s %s %d %d %d \n",prenom,nom,nomutilisateur,motdepasse,sexe,role,&jour,&mois,&annee)!=EOF)
      {
        gtk_list_store_append(store, &iter);
				gtk_list_store_set(store,&iter,Prenom,prenom,Nom,nom,Nomutilisateur,nomutilisateur,Motdepasse,motdepasse,Sexe,sexe,Role,role,Jour,jour,Mois,mois,Annee,annee, -1);

      }
      fclose(f);
	
	gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
			  g_object_unref(store);
}
    }
}


/////////////////////////////////////////////////////////////////////////////////////////////////
void rech_personne ( char nomutilisateur_rech[20], GtkWidget *liste)

{

FILE *f;
char prenom[20];
char nom[20];
char nomutilisateur[20];
char motdepasse[20];
char sexe[20];
char role[20];
int jour,mois,annee;	
personne n;
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
if (store==NULL){

renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",Prenom,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",Nom,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nomutilisateur",renderer,"text",Nomutilisateur,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("motdepasse",renderer,"text",Motdepasse,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",Sexe,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("role",renderer,"text",Role,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",Jour,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("mois",renderer,"text",Mois,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("annee",renderer,"text",Annee,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

}

 store=gtk_list_store_new(COLUMNS,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
f=fopen("utilisateur.txt","r");
if (f==NULL)
{
return;}
else{


f=fopen("utilisateur.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %d %d %d \n",prenom,nom,nomutilisateur,motdepasse,sexe,role,&jour,&mois,&annee)!=EOF)

{

if (strstr(prenom,nomutilisateur_rech)!=NULL||strstr(nom,nomutilisateur_rech)!=NULL||strstr(nomutilisateur,nomutilisateur_rech)!=NULL ){
    gtk_list_store_append (store,&iter);
    gtk_list_store_set(store,&iter,Prenom,prenom,Nom,nom,Nomutilisateur,nomutilisateur,Motdepasse,motdepasse,Sexe,sexe,Role,role,Jour,jour,Mois,mois,Annee,annee, -1);
}}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);}}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

