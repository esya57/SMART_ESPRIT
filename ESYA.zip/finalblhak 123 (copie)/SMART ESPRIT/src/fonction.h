#include<gtk/gtk.h>
#include<stdio.h>
#include<string.h>

typedef struct   
{
int jour;
int mois;
int annee;
}date;

typedef struct  
{
char prenom[20];
char nom[20];
char nomutilisateur[20];
char motdepasse[20];
char sexe[20];
char role[20];
date datnaissance;
}personne;

void afficher_personne(GtkWidget *liste);
int verif(char log[],char pw[]);
void rech_personne ( char nomutilisateur_rech[20], GtkWidget *liste);




